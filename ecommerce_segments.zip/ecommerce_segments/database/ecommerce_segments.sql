-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 24, 2025 at 10:38 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ecommerce_segments`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `min_sale_count` int(11) NOT NULL,
  `a_hour` int(11) NOT NULL,
  `a_minute` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `rdate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `min_sale_count`, `a_hour`, `a_minute`, `status`, `rdate`) VALUES
('admin', 'admin', 3, 12, 0, 2, '24-04-2025');

-- --------------------------------------------------------

--
-- Table structure for table `cs_cart`
--

CREATE TABLE `cs_cart` (
  `id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `rdate` varchar(20) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `category` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_cart`
--

INSERT INTO `cs_cart` (`id`, `uname`, `pid`, `status`, `rdate`, `bill_id`, `price`, `category`) VALUES
(1, 'Sheetha', 6, 1, '24-04-2025', 1, 37000, 'Laptop');

-- --------------------------------------------------------

--
-- Table structure for table `cs_category`
--

CREATE TABLE `cs_category` (
  `id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_category`
--

INSERT INTO `cs_category` (`id`, `category`) VALUES
(1, 'Mobile'),
(2, 'Laptop'),
(3, 'Men-TShirt'),
(4, 'Men-Shirt'),
(5, 'Women-Cloth'),
(6, 'Electronic Products');

-- --------------------------------------------------------

--
-- Table structure for table `cs_email`
--

CREATE TABLE `cs_email` (
  `id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_email`
--

INSERT INTO `cs_email` (`id`, `subject`, `message`) VALUES
(1, 'We have Missed You! Lets Catch Up', '<br><br>We noticed you have not been around lately — and we miss having you with us! Is there anything we can do to make your experience better? <br>We wouldd love to hear from you or help you get the most out of your membership. Looking forward to seeing you back! <br><br>by<br>The Team<br>Shopping'),
(2, 'A Little Something to Say We Miss You', '<br><br>We value you as a customer and noticed you have been a bit quiet. To welcome you back, here is a **special offer just for you**: <br>valid for the next 3 days! Let us know if there''s anything we can assist you with. <br><br>by<br>The Team<br>Shopping'),
(3, 'Help Us Improve – Quick Feedback', '<br><br>We noticed a drop in your activity and just wanted to check in. We are always striving to improve and would really appreciate your thoughts. <br>Would you mind taking 2 minutes to fill out this quick survey?  <br><br>by<br>The Team<br>Shopping'),
(4, 'Your Membership Benefits Are Waiting', '<br><br>Just a friendly reminder — your account comes with exclusive benefits you might not be using yet. Do not let them go to waste! <br>Click below to rediscover all the value we offer: We’d love to have you back in action! <br><br>by<br>The Team<br>Shopping'),
(5, 'Do not Lose Your Rewards – Act Now!', '<br><br>This is a quick heads-up that your account has been inactive, and you may soon miss out on your rewards or special member privileges. <br>We really do not want that to happen. Re-engage today to keep your perks active: We’re here if you need anything! <br><br>by<br>The Team<br>Shopping\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `cs_message`
--

CREATE TABLE `cs_message` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `off_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_message`
--

INSERT INTO `cs_message` (`id`, `message`, `off_type`) VALUES
(1, 'A premium freebie in every order, just for our Gold members!', 2),
(2, 'Gold-only drop — get exclusive access to our limited collection before it goes public.', 2),
(3, 'You''re one step away from Gold — and we’ve got a gift to help you get there!', 2),
(4, 'Happy Anniversary with us! Here’s a luxury gift just for you', 1),
(5, 'Small gifts — here''s something shiny for our Silver members.', 1),
(6, 'Silver is sweet. Let’s make it sweeter with this gift.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cs_offer`
--

CREATE TABLE `cs_offer` (
  `id` int(11) NOT NULL,
  `offer` varchar(30) NOT NULL,
  `offer_type` int(11) NOT NULL,
  `min_purchase` double NOT NULL,
  `discount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_offer`
--

INSERT INTO `cs_offer` (`id`, `offer`, `offer_type`, `min_purchase`, `discount`) VALUES
(1, 'Gold', 2, 50000, 10),
(2, 'Silver', 1, 30000, 7),
(3, 'Normal', 0, 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `cs_product`
--

CREATE TABLE `cs_product` (
  `id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  `product` varchar(50) NOT NULL,
  `price` bigint(20) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `detail` varchar(100) NOT NULL,
  `star` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_product`
--

INSERT INTO `cs_product` (`id`, `category`, `product`, `price`, `photo`, `detail`, `star`) VALUES
(1, 'Electronic Products', 'Momentum4 Wireless Headphone', 24990, 'P1shopping.jpg', 'Momentum4 Wireless Graphite', 0),
(2, 'Electronic Products', 'AirPods4', 12900, 'P2airpods-4-select-202409_FV1.jpg', 'New Apple Airpods', 0),
(3, 'Electronic Products', 'Digital Action Camera', 29990, 'P3camera1.jpg', 'GoPro Hero12 Waterproof Digital Action Camera with Front&Rear LCD Screens,5.3K60 Ultra Hd Video', 0),
(4, 'Electronic Products', 'Sony Alpha Mirrorless Camera', 73000, 'P4camera2.jpg', 'Sony Alpha ILCE-6400L 24.2MP Mirrorless Camera (Black) with 16-50mm Power Zoom Lens', 0),
(5, 'Electronic Products', 'Asus Laptop', 29990, 'P5lap1.jpg', 'ASUS Vivobook Go 15 15.6" Laptop AMD Ryzen 5', 0),
(6, 'Laptop', 'HP Laptop', 37000, 'P6hplap1.jpg', 'HP Laptop 15 AMD Ryzen 5 7520U', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cs_purchase`
--

CREATE TABLE `cs_purchase` (
  `id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL,
  `rdate` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_purchase`
--

INSERT INTO `cs_purchase` (`id`, `uname`, `amount`, `rdate`) VALUES
(1, 'Sheetha', 37000, '24-04-2025');

-- --------------------------------------------------------

--
-- Table structure for table `cs_register`
--

CREATE TABLE `cs_register` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `offer_type` int(11) NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `location` varchar(30) NOT NULL,
  `rdate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_register`
--

INSERT INTO `cs_register` (`id`, `name`, `mobile`, `email`, `uname`, `pass`, `gender`, `offer_type`, `customer_id`, `age`, `location`, `rdate`) VALUES
(1, 'Sheetha', 8856733472, 'sheetha@gmail.com', 'Sheetha', '1234', 'Female', 2, 'CUST0292', 35, 'Kolkata', '10-12-2023'),
(2, 'Ravi', 9988776655, 'ravi@gmail.com', 'ravi', '1234', 'Male', 1, 'CUST0112', 58, 'Chennai', '03-09-2023'),
(3, 'Ramya', 9034566264, 'ramya12@gmail.com', 'ramya', '1234', 'Female', 0, 'CUSTX0013', 27, 'Kolkata', '06-01-2024'),
(4, 'Gopinath', 9517534568, 'gopinath@gmail.com', 'gopinath', '1234', 'Male', 1, 'CUST0370', 43, 'Chennai', '10-11-2022'),
(5, 'Sankar', 9517534568, 'sankar25@gmail.com', 'sankar', '1234', 'Male', 0, 'CUSTX0040', 33, 'Ahmedabad', '1/17/2023');

-- --------------------------------------------------------

--
-- Table structure for table `cs_review`
--

CREATE TABLE `cs_review` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `review` varchar(100) NOT NULL,
  `star` int(11) NOT NULL,
  `rdate` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `review_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_review`
--

INSERT INTO `cs_review` (`id`, `pid`, `uname`, `review`, `star`, `rdate`, `status`, `review_code`) VALUES
(1, 1, 'suresh', 'useful product', 5, '21-12-2024', 1, '53157'),
(2, 6, 'suresh', 'working easy', 4, '21-12-2024', 0, '76708'),
(3, 8, 'suresh', 'Super Laptop', 5, '21-12-2024', 1, '18201'),
(4, 5, 'suresh', 'good', 4, '27-12-2024', 0, '77201'),
(5, 5, 'suresh', 'good', 4, '27-12-2024', 0, '54674');

-- --------------------------------------------------------

--
-- Table structure for table `cs_search`
--

CREATE TABLE `cs_search` (
  `id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `keyword` varchar(50) NOT NULL,
  `scount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs_search`
--

INSERT INTO `cs_search` (`id`, `uname`, `keyword`, `scount`) VALUES
(1, 'suresh', 'mobile', 1),
(2, 'suresh', 'oppo', 2);
