import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Sample: Load your data here
# df = pd.read_csv("your_file.csv")
filename = 'static/dataset/dataset.csv'
df = pd.read_csv(filename, header=0)
    
# Optional: Convert location to numerical labels if not already
df['Location'] = pd.factorize(df['Location(India)'])[0]

# Plot settings
sns.set(style="whitegrid")
fig, axs = plt.subplots(2, 3, figsize=(18, 10))
plt.subplots_adjust(hspace=0.4, wspace=0.3)

# 1. Pie chart of customer segments
segment_counts = df['Segment'].value_counts()
axs[0, 0].pie(segment_counts, labels=segment_counts.index, autopct='%1.1f%%', colors=sns.color_palette("Set2"))
axs[0, 0].set_title("Customer Segments Distribution")

# 2. Boxplot of RFM Score by Segment
sns.boxplot(data=df, x='Segment', y='RFM Score', ax=axs[0, 1], palette="Set2")
axs[0, 1].set_title("RFM Score by Segment")

# 3. Scatter plot Frequency vs Monetary
sns.scatterplot(data=df, x='Frequency', y='Monetary', hue='Segment', ax=axs[0, 2], palette="Set2", edgecolor='w')
axs[0, 2].set_title("Frequency vs Monetary")

# 4. Recency histogram
sns.histplot(df['Recency'], kde=True, ax=axs[1, 0], color='orange')
axs[1, 0].set_title("Recency Distribution")

# 5. Bar plot of customer counts by location
sns.countplot(data=df, x='Location', ax=axs[1, 1], palette='Set2')
axs[1, 1].set_title("Customer Count by Location")

# 6. Hide unused subplot
axs[1, 2].axis('off')

# Show plot
plt.tight_layout()
plt.show()
