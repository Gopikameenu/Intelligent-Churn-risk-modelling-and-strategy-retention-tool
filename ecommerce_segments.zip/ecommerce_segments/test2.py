import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


filename = 'static/dataset/dataset.csv'
df = pd.read_csv(filename, header=0)
segment_counts = df['Segment'].value_counts()
plt.figure(figsize=(6, 6))
plt.pie(segment_counts, labels=segment_counts.index, autopct='%1.1f%%', startangle=140, colors=plt.cm.Paired.colors)
plt.title("Customer Segments Distribution")
plt.axis('equal')
plt.savefig('static/graph/graph1.png')
plt.show()
