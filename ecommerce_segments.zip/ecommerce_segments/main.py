# main.py
import os
import base64
import io
import math
from flask import Flask, render_template, Response, redirect, request, session, abort, url_for
import mysql.connector
import hashlib
import datetime
import calendar
import random
from random import randint
from urllib.request import urlopen
import webbrowser
from plotly import graph_objects as go
from datetime import datetime
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import plotly.express as px
from werkzeug.utils import secure_filename
from PIL import Image
import urllib.request
import urllib.parse
import socket    
import csv

import matplotlib as mpl
import seaborn as sns
from matplotlib import pyplot as plt
from collections import OrderedDict
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  charset="utf8",
  database="ecommerce_segments"

)
app = Flask(__name__)
##session key
app.secret_key = 'abcdef'
#######
UPLOAD_FOLDER = 'static/upload'
ALLOWED_EXTENSIONS = { 'csv'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
#####
@app.route('/', methods=['GET', 'POST'])
def index():
    msg=""

    
    if request.method=='POST':
        uname=request.form['uname']
        pwd=request.form['pass']
        cursor = mydb.cursor()
        cursor.execute('SELECT * FROM cs_register WHERE uname = %s AND pass = %s', (uname, pwd))
        account = cursor.fetchone()
        if account:

            
            session['username'] = uname
            return redirect(url_for('userhome'))
        else:
            msg = 'Incorrect username/password!'
    return render_template('index.html',msg=msg)

@app.route('/alert_mail', methods=['GET', 'POST'])
def alert_mail():
    msg=""
    mdata=[]
    st=""
    mycursor = mydb.cursor()
    mycursor.execute('SELECT * FROM admin')
    rw = mycursor.fetchone()
    ah=rw[3]
    am=rw[4]
    status=rw[5]
    cdate=rw[6]
    
    mycursor.execute('SELECT * FROM cs_register WHERE offer_type=0')
    dd = mycursor.fetchall()

    import datetime
    now1 = datetime.datetime.now()
    rdate=now1.strftime("%d-%m-%Y")
    edate1=now1.strftime("%Y-%m-%d")
    rtime=now1.strftime("%H:%M")
    #print(rtime)
    
    rtime1=rtime.split(':')
    rh=int(rtime1[0])
    rm=int(rtime1[1])


    if ah==rh and rm>=am:
        if rdate==cdate:
            if status<2:
                st="1"
                mycursor.execute("update admin set status=status+1,rdate=%s",(rdate,))
                mydb.commit()
                for ds in dd:
                    md=[]
                    name=ds[1]
                    email=ds[3]
                    print(email)

                    subj=""
                    mess=""
                    mycursor.execute('SELECT * FROM cs_email order by rand() limit 0,1')
                    gg = mycursor.fetchall()
                    for g1 in gg:
                        
                        subj=g1[1]
                        mess=g1[2]

                    mess1="Dear "+name+", "+mess
                    md.append(email)
                    md.append(subj)
                    md.append(mess1)
                    mdata.append(md)
                    #print(mdata)
        else:
            mycursor.execute("update admin set rdate=%s",(rdate,))
            mydb.commit()
        
            

    
    
    
    
        
    return render_template('alert_mail.html',msg=msg,mdata=mdata,st=st)


@app.route('/login', methods=['GET', 'POST'])
def login():
    msg=""

    
    if request.method=='POST':
        uname=request.form['uname']
        pwd=request.form['pass']
        cursor = mydb.cursor()
        cursor.execute('SELECT * FROM admin WHERE username = %s AND password = %s', (uname, pwd))
        account = cursor.fetchone()
        if account:
            session['username'] = uname
            return redirect(url_for('admin'))
        else:
            msg = 'Incorrect username/password!'
    return render_template('login.html',msg=msg)

@app.route('/register', methods=['GET', 'POST'])
def register():
    #import student
    msg=""
    cusid=""
    off_type=""
    rdate=""
    loc=""
    filename = 'static/dataset/dataset_rfm.csv'
    data1 = pd.read_csv(filename, header=0)

    mycursor = mydb.cursor()
    mycursor.execute("SELECT max(id)+1 FROM cs_register")
    maxid = mycursor.fetchone()[0]
    if maxid is None:
        maxid=1

    j=1
    for ds in data1.values:
        if j==maxid:
            cusid=ds[0]
            segment=ds[9]
            rdate=ds[4]
            loc=ds[3]
            if segment=="Gold Customer":
                off_type="2"
            elif segment=="Silver Customer":
                off_type="1"
            else:
                off_type="0"
            break
        j+=1    

    #import datetime
    #now1 = datetime.datetime.now()
    #rdate=now1.strftime("%d-%m-%Y")
    
    if request.method=='POST':
        name=request.form['name']
        mobile=request.form['mobile']
        email=request.form['email']
        uname=request.form['uname']
        pass1=request.form['password']
        gender=request.form['gender']
        age=request.form['age']
        location=request.form['location']
    
        
        
        mycursor.execute("SELECT count(*) FROM cs_register where uname=%s",(uname,))
        cnt = mycursor.fetchone()[0]

        if cnt==0:
            
                    
            sql = "INSERT INTO cs_register(id,name,mobile,email,uname,pass,gender,offer_type,customer_id,age,location,rdate) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            val = (maxid,name,mobile,email,uname,pass1,gender,off_type,cusid,age,location,rdate)
            mycursor.execute(sql, val)
            mydb.commit()            
            #print(mycursor.rowcount, "Registered Success")
            msg="sucess"
            #if mycursor.rowcount==1:
            return redirect(url_for('index'))
        else:
            msg='Already Exist'
    return render_template('register.html',msg=msg,cusid=cusid,loc=loc)

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    msg=""
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_category")
    data = mycursor.fetchall()

    
        
    if request.method=='POST':
        category=request.form['category']
        product=request.form['product']
        price=request.form['price']
        detail=request.form['detail']
        
    
        file = request.files['file']
        mycursor.execute("SELECT max(id)+1 FROM cs_product")
        maxid = mycursor.fetchone()[0]
        if maxid is None:
            maxid=1
            
        try:
            if file.filename == '':
                flash('No selected file')
                return redirect(request.url)
            if file:
                fn=file.filename
                fnn="P"+str(maxid)+fn  
                #fn1 = secure_filename(fn)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], fnn))
                
        except:
            print("dd")
        
        

        photo="P"+str(maxid)+fn   
        sql = "INSERT INTO cs_product(id,category,product,price,photo,detail) VALUES (%s, %s, %s, %s, %s, %s)"
        val = (maxid,category,product,price,photo,detail)
        mycursor.execute(sql, val)
        mydb.commit()            
        #print(mycursor.rowcount, "Registered Success")
        result="sucess"
        if mycursor.rowcount==1:
            return redirect(url_for('add_product'))
        else:
            msg='Already Exist'

    if act=="del":
        did = request.args.get('did')
        mycursor.execute('delete from cs_product WHERE id = %s', (did, ))
        mydb.commit()
        return redirect(url_for('add_product'))

    
        
    mycursor.execute("SELECT * FROM cs_product")
    data2 = mycursor.fetchall()
    
    return render_template('add_product.html',msg=msg,data=data,data2=data2)

@app.route('/offer', methods=['GET', 'POST'])
def offer():
    msg=""
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_offer")
    data = mycursor.fetchall()


    
    return render_template('offer.html',msg=msg,data=data)

@app.route('/offer_edit', methods=['GET', 'POST'])
def offer_edit():
    msg=""
    fid = request.args.get('fid')
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_offer where id=%s",(fid,))
    data = mycursor.fetchone()

    
        
    if request.method=='POST':
        offer=request.form['offer']
        min_purchase=request.form['min_purchase']
        discount=request.form['discount']
        mycursor.execute("update cs_offer set offer=%s,min_purchase=%s,discount=%s where id=%s",(offer,min_purchase,discount,fid))
        mydb.commit()
        
        return redirect(url_for('offer'))
        
      
    return render_template('offer_edit.html',msg=msg,data=data)

@app.route('/view_cus', methods=['GET', 'POST'])
def view_cus():
    msg=""
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_register where offer_type=0")
    data = mycursor.fetchall()


    
    return render_template('view_cus.html',msg=msg,data=data)

@app.route('/cus_edit', methods=['GET', 'POST'])
def cus_edit():
    msg=""
    cid = request.args.get('cid')
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_register where id=%s",(cid,))
    data = mycursor.fetchone()

    
        
    if request.method=='POST':
        email=request.form['email']
       
        mycursor.execute("update cs_register set email=%s where id=%s",(email,cid))
        mydb.commit()
        
        return redirect(url_for('view_cus'))
        
      
    return render_template('cus_edit.html',msg=msg,data=data)



@app.route('/cus_alert', methods=['GET', 'POST'])
def cus_alert():
    msg=""
    
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM admin")
    data = mycursor.fetchone()

    
        
    if request.method=='POST':
        a_hour=request.form['a_hour']
        a_minute=request.form['a_minute']
       
        mycursor.execute("update admin set a_hour=%s,a_minute=%s",(a_hour,a_minute))
        mydb.commit()
        
        return redirect(url_for('view_cus'))        
      
    return render_template('cus_alert.html',msg=msg,data=data)

@app.route('/cus_mail', methods=['GET', 'POST'])
def cus_mail():
    msg=""
    
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_email")
    data = mycursor.fetchall()

    return render_template('cus_mail.html',msg=msg,data=data)

@app.route('/cus_edit2', methods=['GET', 'POST'])
def cus_edit2():
    msg=""
    cid = request.args.get('cid')
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_email where id=%s",(cid,))
    data = mycursor.fetchone()

    
        
    if request.method=='POST':
        subject=request.form['subject']
        message=request.form['message']
       
        mycursor.execute("update cs_email set subject=%s,message=%s where id=%s",(subject,message,cid))
        mydb.commit()
        
        return redirect(url_for('cus_mail'))        
      
    return render_template('cus_edit2.html',msg=msg,data=data)

@app.route('/sale_edit', methods=['GET', 'POST'])
def sale_edit():
    msg=""
    fid = request.args.get('fid')
    act = request.args.get('act')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM admin where username='admin'")
    data = mycursor.fetchone()

    
        
    if request.method=='POST':
        
        min_sale_count=request.form['min_sale_count']
        
        mycursor.execute("update admin set min_sale_count=%s where username='admin'",(min_sale_count,))
        mydb.commit()
        
        return redirect(url_for('offer'))
        
      
    return render_template('sale_edit.html',msg=msg,data=data)


@app.route('/userhome', methods=['GET', 'POST'])
def userhome():
    msg=""
    msg2=""
    cnt=0
    uname=""
    mess=""
    off_mess=""
    act = request.args.get('act')
    cat = request.args.get('cat')
    poffer = request.args.get('poffer')
    if 'username' in session:
        uname = session['username']
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_register where uname=%s",(uname,))
    usr = mycursor.fetchone()
    name=usr[1]
    email=usr[3]
    uff=usr[7]


    mycursor.execute("SELECT * FROM cs_offer where offer_type=%s",(uff,))
    fd1 = mycursor.fetchone()
    offer=fd1[1]
    per=fd1[4]

    mycursor.execute("SELECT * FROM cs_message where off_type=%s order by rand()",(uff,))
    fd1 = mycursor.fetchall()
    for fd in fd1:
        off_mess=fd[1]
        
    mycursor.execute("SELECT * FROM cs_category")
    data2 = mycursor.fetchall()

    ########offer###############
    pur_amt=0
    oftype=0
    st=""
    mycursor.execute("SELECT count(*) FROM cs_cart where uname=%s && status=1",(uname,))
    fd1 = mycursor.fetchone()[0]
    print("ss")
    print(fd1)
    if fd1>0:
        mycursor.execute("SELECT sum(price) FROM cs_cart where uname=%s && status=1",(uname,))
        fd2 = mycursor.fetchone()[0]
        pur_amt=fd2
        print(pur_amt)

        mycursor.execute("SELECT count(*) FROM cs_offer where min_purchase<=%s && offer_type=2",(pur_amt,))
        fd3 = mycursor.fetchone()[0]

        mycursor.execute("SELECT count(*) FROM cs_offer where min_purchase<=%s && offer_type=1",(pur_amt,))
        fd4 = mycursor.fetchone()[0]

        if fd3>0:
            oftype=2
            print(oftype)
        elif fd4>0:
            oftype=1
            print(oftype)
        else:
            oftype=0

    if oftype==uff:
        st="1"
        print("st1")
    else:
        st="2"
        print("st2")

    print(usr[7])
    
    if oftype>0 and st=="2":
        mycursor.execute("SELECT * FROM cs_offer where offer_type=%s",(oftype,))
        data3 = mycursor.fetchone()
        offer=data3[1]
        print(offer)
        
        print("offer")
        
        msg2="yes"
        mess="Dear "+name+", "+offer+" offer for you, Recommended Products - Click http://localhost:5000/recommend1?user="+uname
        mycursor.execute("update cs_register set offer_type=%s where uname=%s",(oftype,uname))
        mydb.commit()
    ####################

    cc=""
    if cat is None:
        cc=""
    else:
        cc="1"
    
    if request.method=='POST':
        getval=request.form['getval']
        cat="%"+getval+"%"
        prd="%"+getval+"%"
        det="%"+getval+"%"
        mycursor.execute("SELECT * FROM cs_product where category like %s || product like %s || detail like %s  order by star desc",(cat,prd,det))
        data = mycursor.fetchall()

        mycursor.execute("SELECT count(*) FROM cs_search where uname=%s && keyword=%s",(uname,getval))
        cnt2 = mycursor.fetchone()[0]
        if cnt2==0:

            mycursor.execute("SELECT max(id)+1 FROM cs_search")
            maxid1 = mycursor.fetchone()[0]
            if maxid1 is None:
                maxid1=1
                
            sql = "INSERT INTO cs_search(id, uname, keyword, scount) VALUES (%s, %s, %s, %s)"
            val = (maxid1, uname, getval, '1')
            mycursor.execute(sql,val)
            mydb.commit()
        else:
            mycursor.execute('update cs_search set scount=scount+1 WHERE uname=%s && keyword=%s', (uname,getval))
            mydb.commit()

        
    elif cc=="1":
        mycursor.execute("SELECT * FROM cs_product where category=%s order by star desc",(cat,))
        data = mycursor.fetchall()
    else:
        mycursor.execute("SELECT * FROM cs_product order by star desc")
        data = mycursor.fetchall()

    import datetime
    now = datetime.datetime.now()
    rdate=now.strftime("%d-%m-%Y")
    
    if act=="cart":
        pid = request.args.get('pid')
        mycursor.execute('SELECT count(*) FROM cs_cart WHERE uname=%s && pid = %s && status=0', (uname, pid))
        num = mycursor.fetchone()[0]

        mycursor.execute("SELECT * FROM cs_product where id=%s",(pid,))
        pdata = mycursor.fetchone()
        price=pdata[3]
        cat=pdata[1]
        if num==0:
            mycursor.execute("SELECT max(id)+1 FROM cs_cart")
            maxid = mycursor.fetchone()[0]
            if maxid is None:
                maxid=1

            pc=0
            if poffer=="yes":
                mycursor.execute("SELECT * FROM cs_offer where offer_type=%s",(uff,))
                rf1 = mycursor.fetchone()
                per=rf1[4]
                dc=(price/100)*per
                fprice=price-dc
                pc=fprice
            else:
                pc=price
                
                
            sql = "INSERT INTO cs_cart(id, uname, pid, status, rdate, price,category) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            val = (maxid, uname, pid, '0', rdate, pc, cat)
            mycursor.execute(sql,val)
            mydb.commit()
            return redirect(url_for('userhome'))

    mycursor.execute("SELECT count(*) FROM cs_cart where uname=%s && status=0",(uname,))
    cnt = mycursor.fetchone()[0]
    if cnt>0:
        msg="1"
    else:
        msg=""
    
    return render_template('userhome.html',msg=msg,usr=usr,data=data,cnt=cnt,data2=data2,mess=mess,email=email,msg2=msg2,offer=offer,per=per,off_mess=off_mess)

@app.route('/cart', methods=['GET', 'POST'])
def cart():
    act=""
    pid=""
    did=""
    amount=""
    if 'username' in session:
        uname = session['username']

    cursor = mydb.cursor()
    cursor.execute("SELECT count(*) FROM cs_cart where uname=%s && status=0",(uname, ))
    cnt = cursor.fetchone()[0]
    if cnt>0:
        act="1"
    else:
        act=""
    
    cursor.execute('SELECT c.id,p.product,c.price,p.detail,p.photo,c.rdate FROM cs_cart c,cs_product p where c.pid=p.id and c.uname=%s and c.status=0', (uname, ))
    data = cursor.fetchall()

    cursor.execute("SELECT * FROM cs_cart where uname=%s && status=0",(uname, ))
    dr = cursor.fetchall()
    amt=0
    for dv in dr:
        pid=dv[2]
        cursor.execute("SELECT price FROM cs_product where id=%s",(pid, ))
        pr = cursor.fetchone()[0]
        amt+=dv[6]
        

    
    '''if request.method=='GET':
        act = request.args.get('act')
        pid = request.args.get('pid')
        did = request.args.get('did')
        if act=="ok":
            mycursor = mydb.cursor()
            mycursor.execute("SELECT max(id)+1 FROM cs_cart")
            maxid = mycursor.fetchone()[0]
            if maxid is None:
                maxid=1
            now = datetime.datetime.now()
            rdate=now.strftime("%d-%m-%Y")
            
            sql = "INSERT INTO cart(id, uname, pid, rdate) VALUES (%s, %s, %s, %s)"
            val = (maxid, uname, pid, rdate)
            mycursor.execute(sql,val)
            mydb.commit()
            return redirect(url_for('cart',data=data))
        if act=="del":
            cursor = mydb.cursor()
            cursor.execute('delete FROM cart WHERE id = %s', (did, ))
            mydb.commit()
            return redirect(url_for('cart',data=data))'''

    if request.method=='POST':
        amount=request.form['amount']
        print("test")
        return redirect(url_for('payment', amount=amt))
            
    return render_template('cart.html', data=data, amount=amt,act=act)


@app.route('/payment', methods=['GET', 'POST'])
def payment():
    msg=""
    mob2=""
    email2=""
    uname=""
    amount=0
    message=""
    st=""
    if 'username' in session:
        uname = session['username']
    if request.method=='GET':
        amount = request.args.get('amount')

    import datetime
    now = datetime.datetime.now()
    rdate=now.strftime("%d-%m-%Y")
    cursor = mydb.cursor()

    #print("uname="+uname)
    cursor.execute("SELECT * FROM cs_register where uname=%s",(uname, ))
    rd=cursor.fetchone()
    name=rd[1]
    mob1=rd[2]
    email=rd[3]

    x=0
    if request.method=='POST':
        card=request.form['card']
        amount=request.form['amount']
        

        cursor.execute("SELECT * FROM cs_register where uname=%s",(uname, ))
        rr=cursor.fetchone()
        mob2=rr[3]
        email2=rr[4]
        
        cursor.execute("SELECT max(id)+1 FROM cs_purchase")
        maxid = cursor.fetchone()[0]
        if maxid is None:
            maxid=1

        st="1"
        message="Dear "+name+", Amount Rs."+amount+" Purchased Success, Recommended Products - Click http://localhost:5000/recommend1?user="+uname
        #url="http://iotcloud.co.in/testmail/sendmail.php?email="+email+"&message="+message
        #webbrowser.open_new(url)

        cursor.execute('update cs_cart set status=1,bill_id=%s WHERE uname=%s && status=0', (maxid, uname ))
        mydb.commit()

        sql = "INSERT INTO cs_purchase(id, uname, amount, rdate) VALUES (%s, %s, %s, %s)"
        val = (maxid, uname, amount, rdate)
        cursor.execute(sql,val)
        mydb.commit()
        msg="1"

        

    return render_template('payment.html', msg=msg, amount=amount,mess=message,email=email,st=st)


@app.route('/purchase', methods=['GET', 'POST'])
def purchase():
    uname=""
    amount=0
    if 'username' in session:
        uname = session['username']
    
    
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM cs_purchase where uname=%s",(uname, ))
    data1=cursor.fetchall()

    return render_template('purchase.html', data1=data1)

@app.route('/view', methods=['GET', 'POST'])
def view():
    uname=""
    amount=0
    if 'username' in session:
        uname = session['username']
    
    bid = request.args.get('bid')
    cursor = mydb.cursor()
    cursor.execute('SELECT c.id,p.product,c.price,p.detail,p.photo,c.rdate FROM cs_cart c,cs_product p where c.pid=p.id and c.bill_id=%s', (bid, ))
    data = cursor.fetchall()

    return render_template('view.html', data=data)

@app.route('/add_review', methods=['GET', 'POST'])
def add_review():
    msg=""
    act=""
    message=""
    uname=""
    rid=""
    pid = request.args.get('pid')
    if 'username' in session:
        uname = session['username']
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_register where uname=%s",(uname,))
    usr = mycursor.fetchone()
    email=usr[3]
    name=usr[1]

    mycursor.execute("SELECT * FROM cs_product where id=%s",(pid,))
    prd = mycursor.fetchone()

    now = datetime.datetime.now()
    rdate=now.strftime("%d-%m-%Y")
    
    mycursor.execute("SELECT count(*) FROM cs_review where pid=%s && status=1",(pid,))
    cnt = mycursor.fetchone()[0]
    if cnt>0:
        act="1"
    mycursor.execute("SELECT * FROM cs_review where pid=%s && status=1",(pid,))
    data1 = mycursor.fetchall()

    rn=randint(10000,99999)

    if request.method=='POST':
        star=request.form['star']
        review=request.form['review']
        mycursor.execute("SELECT max(id)+1 FROM cs_review")
        maxid = mycursor.fetchone()[0]
        if maxid is None:
            maxid=1
            
        sql = "INSERT INTO cs_review(id,pid,uname,review,star,rdate,status,review_code) VALUES (%s, %s, %s, %s, %s,%s,%s,%s)"
        val = (maxid,pid,uname,review,star,rdate,'0',str(rn))
        mycursor.execute(sql,val)
        mydb.commit()
        #msg="Your Review has sent.."
        message="Dear "+name+", Review Code: "+str(rn)
        #url="http://iotcloud.co.in/testmail/sendmail.php?email="+email+"&message="+message
        #webbrowser.open_new(url)
        msg="1"
        rid=str(maxid)
        #return redirect(url_for('review_code',rid=maxid))
        

    return render_template('add_review.html',msg=msg,usr=usr,data1=data1,act=act,pid=pid,prd=prd,mess=message,email=email,rid=rid)

@app.route('/review_code', methods=['GET', 'POST'])
def review_code():
    msg=""
    uname=""
    rid = request.args.get('rid')
    if 'username' in session:
        uname = session['username']
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_register where uname=%s",(uname,))
    usr = mycursor.fetchone()
    email=usr[3]
    name=usr[1]

    mycursor.execute("SELECT * FROM cs_review where id=%s",(rid,))
    data1 = mycursor.fetchone()
    code=data1[7]
    pid=data1[1]
    if request.method=='POST':
        rcode=request.form['review_code']
        if rcode==code:
            mycursor.execute("SELECT count(*) FROM cs_cart where pid=%s && uname=%s && status=1",(pid,uname))
            cnt = mycursor.fetchone()[0]
            if cnt>0:
                mycursor.execute('update cs_review set status=1 WHERE id = %s', (rid,))
                mydb.commit()

                mycursor.execute("SELECT * FROM cs_review where pid=%s && status=1",(pid,))
                pdd = mycursor.fetchall()
                sr=0
                i=0
                for pn in pdd:
                    sr+=pn[4]
                    i+=1
                ss=sr/i
                star=int(ss)
                mycursor.execute('update cs_product set star=%s WHERE id = %s', (star,pid))
                mydb.commit()
                    
            
                msg="Your Review has posted"
            else:
                msg="Your Review has not posted! not buy this product!"
        else:
            msg="Review Code wrong!"


            
    return render_template('review_code.html',msg=msg)

@app.route('/search', methods=['GET', 'POST'])
def search():
    msg=""
    cnt=0
    uname=""
    act = request.args.get('act')
    cat = request.args.get('cat')
    if 'username' in session:
        uname = session['username']
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_register where uname=%s",(uname,))
    usr = mycursor.fetchone()

    mycursor.execute("SELECT * FROM cs_search where uname=%s order by scount desc",(uname,))
    data2 = mycursor.fetchall()

    cc=""
    if cat is None:
        cc=""
    else:
        cc="1"

    if cc=="1":
        cat="%"+cat+"%"
        prd="%"+cat+"%"
        det="%"+cat+"%"
        mycursor.execute("SELECT * FROM cs_product where category like %s || product like %s || detail like %s  order by star desc",(cat,prd,det))
        data = mycursor.fetchall()
    else:
        mycursor.execute("SELECT * FROM cs_product order by star desc")
        data = mycursor.fetchall()

    now = datetime.datetime.now()
    rdate=now.strftime("%d-%m-%Y")
    
    if act=="cart":
        pid = request.args.get('pid')
        mycursor.execute('SELECT count(*) FROM cs_cart WHERE uname=%s && pid = %s && status=0', (uname, pid))
        num = mycursor.fetchone()[0]

        mycursor.execute("SELECT * FROM cs_product where id=%s",(pid,))
        pdata = mycursor.fetchone()
        price=pdata[3]
        cat=pdata[1]
        if num==0:
            mycursor.execute("SELECT max(id)+1 FROM cs_cart")
            maxid = mycursor.fetchone()[0]
            if maxid is None:
                maxid=1
                
            sql = "INSERT INTO cs_cart(id, uname, pid, status, rdate, price,category) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            val = (maxid, uname, pid, '0', rdate, price, cat)
            mycursor.execute(sql,val)
            mydb.commit()
            return redirect(url_for('search'))

    mycursor.execute("SELECT count(*) FROM cs_cart where uname=%s && status=0",(uname,))
    cnt = mycursor.fetchone()[0]
    if cnt>0:
        msg="1"
    else:
        msg=""
    
    return render_template('search.html',msg=msg,usr=usr,data=data,cnt=cnt,data2=data2)


@app.route('/recommend', methods=['GET', 'POST'])
def recommend():
    msg=""
    cnt=0
    uname=""
    act = request.args.get('act')
    cat = request.args.get('cat')
    if 'username' in session:
        uname = session['username']
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_register where uname=%s",(uname,))
    usr = mycursor.fetchone()
    oftype=usr[7]

    mycursor.execute("SELECT * FROM cs_offer where offer_type=%s",(oftype,))
    fd1 = mycursor.fetchone()
    offer=fd1[1]
    per=fd1[4]
    
    mycursor.execute("SELECT * FROM admin where username='admin'")
    usr2 = mycursor.fetchone()
    min_count=usr2[2]

    mycursor.execute("SELECT * FROM cs_product")
    pdata = mycursor.fetchall()
    prdd=[]
    for pr in pdata:

        mycursor.execute("SELECT count(*) FROM cs_cart where pid=%s",(pr[0],))
        pp1 = mycursor.fetchone()[0]
        if pp1<=min_count:
            prdd.append(pr[0])
    data=[] 
    for pv in prdd:
        mycursor.execute("SELECT * FROM cs_product where id=%s order by star desc",(pv,))
        data1 = mycursor.fetchall()
        for rd1 in data1:
            dat=[]
            dat.append(rd1[0])
            dat.append(rd1[1])
            dat.append(rd1[2])
            dat.append(rd1[3])
            dat.append(rd1[4])
            dat.append(rd1[5])
            dat.append(rd1[6])

            dc=(rd1[3]/100)*per
            fprice=rd1[3]-dc
            dat.append(fprice)
            data.append(dat)
        
 
    
    return render_template('recommend.html',msg=msg,usr=usr,data=data,offer=offer,per=per)

@app.route('/recommend1', methods=['GET', 'POST'])
def recommend1():
    msg=""
    cnt=0
    uname=""
    act = request.args.get('act')
    user = request.args.get('user')
    
    
    if 'username' in session:
        uname = session['username']
    else:
        session['username'] = user
        uname=user
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM cs_register where uname=%s",(uname,))
    usr = mycursor.fetchone()
    oftype=usr[7]

    mycursor.execute("SELECT * FROM cs_offer where offer_type=%s",(oftype,))
    fd1 = mycursor.fetchone()
    offer=fd1[1]
    per=fd1[4]
    
    mycursor.execute("SELECT * FROM admin where username='admin'")
    usr2 = mycursor.fetchone()
    min_count=usr2[2]

    mycursor.execute("SELECT * FROM cs_product")
    pdata = mycursor.fetchall()
    prdd=[]
    for pr in pdata:

        mycursor.execute("SELECT count(*) FROM cs_cart where pid=%s",(pr[0],))
        pp1 = mycursor.fetchone()[0]
        if pp1<=min_count:
            prdd.append(pr[0])
    data=[] 
    for pv in prdd:
        mycursor.execute("SELECT * FROM cs_product where id=%s order by star desc",(pv,))
        data1 = mycursor.fetchall()
        for rd1 in data1:
            dat=[]
            dat.append(rd1[0])
            dat.append(rd1[1])
            dat.append(rd1[2])
            dat.append(rd1[3])
            dat.append(rd1[4])
            dat.append(rd1[5])
            dat.append(rd1[6])

            dc=(rd1[3]/100)*per
            fprice=rd1[3]-dc
            dat.append(fprice)
            data.append(dat)
    
    return render_template('recommend1.html',msg=msg,usr=usr,data=data,offer=offer,per=per)


@app.route('/admin', methods=['GET', 'POST'])
def admin():
    msg=""

        
    return render_template('admin.html',msg=msg)

@app.route('/load_data', methods=['GET', 'POST'])
def load_data():
    msg=""
    cnt=0
    filename = 'static/dataset/dataset.csv'
    data1 = pd.read_csv(filename, header=0)
    data2 = list(data1.values.flatten())
    data=[]
    i=0
    sd=len(data1)
    rows=len(data1.values)
    
    #print(str(sd)+" "+str(rows))
    for ss in data1.values:
        cnt=len(ss)
        if i<200:        
            data.append(ss)
        i+=1
    cols=cnt
    #if request.method=='POST':
    #    return redirect(url_for('preprocess'))
    return render_template('load_data.html',data=data, msg=msg, rows=rows, cols=cols)

@app.route('/preprocess', methods=['GET', 'POST'])
def preprocess():
    msg=""
    mem=0
    cnt=0
    cols=0
    filename = 'static/dataset/dataset.csv'
    data1 = pd.read_csv(filename, header=0)
    data2 = list(data1.values.flatten())
    cname=[]
    data=[]
    dtype=[]
    dtt=[]
    nv=[]
    i=0
    
    sd=len(data1)
    rows=len(data1.values)
    
    #print(data1.columns)
    col=data1.columns
    #print(data1[0])
    for ss in data1.values:
        cnt=len(ss)
        

    i=0
    while i<cnt:
        j=0
        x=0
        for rr in data1.values:
            dt=type(rr[i])
            if rr[i]!="":
                x+=1
            
            j+=1
        dtt.append(dt)
        nv.append(str(x))
        
        i+=1

    arr1=np.array(col)
    arr2=np.array(nv)
    data3=np.vstack((arr1, arr2))


    arr3=np.array(data3)
    arr4=np.array(dtt)
    
    data=np.vstack((arr3, arr4))
   
    print(data)
    cols=cnt
    mem=float(rows)*0.75

    #if request.method=='POST':
    #    return redirect(url_for('feature_ext'))
    
    return render_template('preprocess.html',data=data, msg=msg, rows=rows, cols=cols, dtype=dtype, mem=mem)


@app.route('/feature', methods=['GET', 'POST'])
def feature():
    msg=""
    cnt=0
    filename = 'static/dataset/dataset.csv'
    df = pd.read_csv(filename)
    # Process the data
    df['Date of Joining'] = pd.to_datetime(df['Date of Joining'], errors='coerce')

    # Feature Engineering
    df['Year of Joining'] = df['Date of Joining'].dt.year
    df['Recency (Days)'] = (datetime.now() - df['Date of Joining']).dt.days
    df['Age Group'] = pd.cut(df['Age'], bins=[0, 25, 35, 50, 100], labels=['<25', '26-35', '36-50', '50+'])
    df['Avg Spend per Purchase'] = df['Monetary'] / df['Frequency']
    df['Activity Rate'] = df['Frequency'] / df['Recency (Days)']

    # RFM Scores
    df['Recency Score'] = pd.qcut(df['Recency'], 3, labels=[3, 2, 1])
    df['Frequency Score'] = pd.qcut(df['Frequency'], 3, labels=[1, 2, 3])
    df['Monetary Score'] = pd.qcut(df['Monetary'], 3, labels=[1, 2, 3])
    df['RFM Score'] = df['Recency Score'].astype(str) + df['Frequency Score'].astype(str) + df['Monetary Score'].astype(str)

    # Choose columns to display
    table_data = df[['Customer ID', 'Age Group', 'Year of Joining', 'Recency (Days)',
                     'Avg Spend per Purchase', 'RFM Score', 'Activity Rate']]

    # Convert to HTML table
    table_html = table_data.to_html(classes='table table-striped', index=False)

    ##graph
    fig_rfm = px.histogram(df, x='RFM Score', title='RFM Score Distribution')
    graph_rfm = fig_rfm.to_html(full_html=False)

    # 2. Average Spend per Age Group
    fig_age = px.bar(df.groupby('Age Group')['Avg Spend per Purchase'].mean().reset_index(),
                     x='Age Group', y='Avg Spend per Purchase', title='Avg Spend by Age Group')
    graph_age = fig_age.to_html(full_html=False)

    # 3. Customers by Location
    fig_loc = px.histogram(df, x='Location(India)', title='Customer Count by Location')
    graph_location = fig_loc.to_html(full_html=False)


    '''table_html = table_data.to_html(classes='table table-striped', index=False)
    plt.figure(figsize=(10, 6))
    sns.set(style="whitegrid")
    scatter = sns.scatterplot(data=df_features, x='ActivityRate', y='RFM Score', hue='AvgValue', palette='viridis', s=100)
    plt.title("RFM Score vs Activity Rate (colored by AvgValue)")
    plt.xlabel("Activity Rate (Frequency / Tenure)")
    plt.ylabel("RFM Score")
    plt.legend(title="AvgValue", bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.savefig('static/graph/graph6.png')
    plt.tight_layout()
    plt.close()'''

   
    return render_template('feature.html',msg=msg,table=table_html,graph_rfm=graph_rfm,
                           graph_age=graph_age,
                           graph_location=graph_location)

#K-Means Clustering for segmentation 
def cluster(filename):
    df = pd.read_csv(filename)
    # Assuming you have a DataFrame `df` with your RFM data
    rfm_data = df[['Recency', 'Frequency', 'Monetary']]
    scaler = StandardScaler()
    rfm_scaled = scaler.fit_transform(rfm_data)
    wcss = []
    for k in range(1, 10):
        kmeans = KMeans(n_clusters=k, random_state=42)
        kmeans.fit(rfm_scaled)
        wcss.append(kmeans.inertia_)

    plt.plot(range(1, 10), wcss, marker='o')
    plt.title('Elbow Method')
    plt.xlabel('Number of clusters')
    plt.ylabel('WCSS')
    plt.show()

#Logistic Regression for churn prediction
def predict(filename):
    df = pd.read_csv(filename)
    df['Churn'] = df['Churn'].map({'Yes': 1, 'No': 0})
    df_encoded = pd.get_dummies(df.drop(['CustomerID'], axis=1), drop_first=True)
    X = df_encoded.drop('Churn', axis=1)
    y = df_encoded['Churn']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    print(confusion_matrix(y_test, y_pred))
    print(classification_report(y_test, y_pred))
    print("AUC Score:", roc_auc_score(y_test, model.predict_proba(X_test)[:, 1]))
        
    
@app.route('/classify', methods=['GET', 'POST'])
def classify():
    msg=""
    cnt=0
    filename = 'static/dataset/dataset_rfm.csv'
    data1 = pd.read_csv(filename, header=0)
    data2 = list(data1.values.flatten())
    data=[]
    i=0
    sd=len(data1)
    rows=len(data1.values)
    
    #print(str(sd)+" "+str(rows))
    for ss in data1.values:
        cnt=len(ss)
        if i<200:        
            data.append(ss)
        i+=1
    cols=cnt
    ##
    df = pd.read_csv(filename)
    segment_counts = df['Segment'].value_counts()

    # Bar Plot
    plt.figure(figsize=(8, 5))
    sns.barplot(x=segment_counts.index, y=segment_counts.values, palette="viridis")

    plt.title("Customer Segments Count")
    plt.xlabel("Segment")
    plt.ylabel("Number of Customers")
    plt.xticks(rotation=15)
    plt.tight_layout()
    #plt.savefig('static/graph/graph6.png')
    #plt.show()


    return render_template('classify.html',data=data, msg=msg, rows=rows, cols=cols)



##########################
@app.route('/logout')
def logout():
    # remove the username from the session if it is there
    session.pop('username', None)
    return redirect(url_for('index'))



if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)


