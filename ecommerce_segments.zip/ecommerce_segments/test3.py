import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


filename = 'static/dataset/dataset.csv'
df = pd.read_csv(filename, header=0)

'''plt.figure(figsize=(8, 6))
sns.boxplot(data=df, x='Segment', y='RFM Score', palette="Set2")
plt.title("RFM Score by Segment")
plt.xticks(rotation=15)
plt.savefig('static/graph/graph2.png')
plt.show()'''

'''plt.figure(figsize=(8, 6))
sns.scatterplot(data=df, x='Frequency', y='Monetary', hue='Segment', palette="Set2", s=100, edgecolor='w')
plt.title("Frequency vs Monetary")
plt.savefig('static/graph/graph3.png')
plt.show()'''


'''plt.figure(figsize=(8, 6))
sns.histplot(df['Recency'], bins=10, kde=True, color='skyblue')
plt.title("Recency Distribution")
plt.xlabel("Recency")
plt.ylabel("Count")
plt.savefig('static/graph/graph4.png')
plt.show()'''


plt.figure(figsize=(10, 6))
sns.countplot(data=df, x='Location(India)', palette='Set2')
plt.title("Customer Count by Location")
plt.xticks(rotation=45)
plt.xlabel("Location")
plt.ylabel("Number of Customers")
plt.savefig('static/graph/graph5.png')
plt.show()
